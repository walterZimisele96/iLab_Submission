package testCases;


import WIMI_IOTF.*;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import utility.Constant;
import utility.WebDr;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;

public class testFlow extends WebDr {

    public Boolean boolLifeServices;
    public Boolean boolASTIServices= false;
    public testFlow(ExtentTest test, ExtentReports extent) {
        this.test = test;
        this.extent = extent;
    }

    public void executeTC(String fn_name,String preferBrowser) throws Exception
    {
        try {
            switch (fn_name) {
                //'Life Apply

                case "IOTF_Registration" : IOTF_Registration(preferBrowser);break;
                case "IOTF_NavMenu" : IOTF_NavMenu(preferBrowser);break;
                case "My_Moments" : My_Moments(preferBrowser);break;
                case "My_Profile" : My_Profile(preferBrowser);break;
                case "Smart_Car" : Smart_Car(preferBrowser);break;
                case"Dashboard": Dashboard(preferBrowser); break;
                case"Leader_board": Leaderboard(preferBrowser);break;
                case"SOS": SOS(preferBrowser);break;
                case "Mobile_Banking" : Mobile_Banking(preferBrowser);break;
                case "Weather_Alert" : weatherAlert(preferBrowser);break;
                default:break;
            }
        } catch (Exception e) {
            wdriver.quit();
        }
    }


    public void IOTF_Registration(String preferBrowser) throws Exception{
        setExcelFile(Constant.Path_TestData + Driver.file_TestData,"Configuration");
        String sURL=getCellData(5,1);
        openApplication(sURL, preferBrowser);
        new IOTF_Registration(wdriver,test).fn_IOTF_Registration();
    }

    public void IOTF_NavMenu(String preferBrowser) throws Exception{

        setExcelFile(Constant.Path_TestData + Driver.file_TestData,"Configuration");
        String sURL=getCellData(5,1);
        openApplication(sURL, preferBrowser);
        new IOTF_NavMenu(wdriver,test).fn_IOTF_NavMenu();

    }

    public void My_Moments(String preferBrowser) throws Exception{

        setExcelFile(Constant.Path_TestData + Driver.file_TestData,"Configuration");
        String sURL=getCellData(5,1);
        openApplication(sURL, preferBrowser);
        new My_Moments(wdriver,test).fn_My_Moments();

    }

    public void My_Profile(String preferBrowser) throws Exception{

        setExcelFile(Constant.Path_TestData + Driver.file_TestData,"Configuration");
        String sURL=getCellData(5,1);
        openApplication(sURL, preferBrowser);
        new My_Profile(wdriver,test).fn_My_Profile();

    }

    public void Smart_Car(String preferBrowser) throws Exception{

        setExcelFile(Constant.Path_TestData + Driver.file_TestData,"Configuration");
        String sURL=getCellData(5,1);
        openApplication(sURL, preferBrowser);
        new Smart_Car(wdriver,test).fn_Smart_Car();

    }

    public void Dashboard(String preferBrowser) throws Exception{

        setExcelFile(Constant.Path_TestData + Driver.file_TestData,"Configuration");
        String sURL=getCellData(5,1);
        openApplication(sURL, preferBrowser);
        new Dashboard(wdriver,test).fn_Dashboard();

    }

    public void Leaderboard(String preferBrowser) throws Exception{

        setExcelFile(Constant.Path_TestData + Driver.file_TestData,"Configuration");
        String sURL=getCellData(5,1);
        openApplication(sURL, preferBrowser);
        new Leaderboard(wdriver,test).fn_Leaderboard();

    }

    public void SOS(String preferBrowser) throws Exception{

        setExcelFile(Constant.Path_TestData + Driver.file_TestData,"Configuration");
        String sURL=getCellData(5,1);
        openApplication(sURL, preferBrowser);
        new SOS(wdriver,test).fn_SOS();

    }

    public void weatherAlert(String preferBrowser) throws Exception{

        setExcelFile(Constant.Path_TestData + Driver.file_TestData,"Configuration");
        String sURL=getCellData(5,1);
        openApplication(sURL, preferBrowser);
        new Weather_Alerts(wdriver,test).fn_WeatherAlerts();

    }





    public void Mobile_Banking(String preferBrowser) throws Exception{
//        setExcelFile(Constant.Path_TestData + Driver.file_TestData,"Configuration");
//        String sURL=getCellData(5,1);
//        openApplication(sURL, preferBrowser);
//        new MobileBanking(wdriver,test).ABSA_MB_Registration();
//        String sPolicyName = getValue("PolicyName");
//        new MobileBanking(wdriver,test).ABSA_MB_Login();
//        new MobileBanking(wdriver,test).fn_Select_Policy(sPolicyName);
//        new MobileBanking(wdriver,test).fn_VerifyPolicy();
//        new MobileBanking(wdriver,test).fn_RegisterClaim();

    }

}