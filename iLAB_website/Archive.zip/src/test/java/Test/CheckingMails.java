package Test;


import java.io.OutputStream;

public class CheckingMails {

    public static void main(String[] args) {
        String aa = "adskagjfilusah|adsfaslk";
        String[] a = aa.split("\\|");
        System.out.println(a[0]);
        Runtime rt = Runtime.getRuntime ();
        try{
            Process p = rt.exec ("wscript C:\\Users\\ABASACG\\Desktop\\ReadMail.vbs "+ "TVN" );
            p.waitFor ();
            int aaaa = p.exitValue ();
            OutputStream oS = p.getOutputStream ();

            System.out.println (oS.toString ());
            System.out.println (oS.toString ());
        }
        catch (Exception e){

        }

    }



}