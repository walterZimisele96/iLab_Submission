package Test;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.net.URL;

public class AndroidDriverTest {
    public static WebDriver wdriver;
    public static void main(String[] args) {
        try {
            DesiredCapabilities capabilities = new DesiredCapabilities();
            capabilities.setCapability("BROWSER_NAME", "Android");
            capabilities.setCapability("platformName", "Android");

            capabilities.setCapability("VERSION", "8.1");
            capabilities.setCapability("deviceName", "Pixel 2 API 27");
            capabilities.setCapability("appPackage", "com.absa.iotfapp");
            capabilities.setCapability("appActivity", "com.absa.iotfapp.SplashScreen"); // This is Launcher activity of your app (you can get it from apk info app)
            capabilities.setCapability("app", "/Users/akhileshsinha/Downloads/APK/app-debug.apk");
            wdriver = new RemoteWebDriver(new URL("http://127.0.0.1:4723/wd/hub"), capabilities);
//            wdriver = new AndroidDriver(new URL("http://127.0.0.1:4723/wd/hub"), capabilities);
            wdriver.findElement(By.xpath("//android.widget.Button[1]")).click();
        }catch(Exception e){
            System.out.println(e.toString());
        }

    }
}
