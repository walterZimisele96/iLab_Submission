package WIMI_IOTF_POM;

import org.yaml.snakeyaml.error.MarkedYAMLException;
import utility.WebDr;

import java.util.HashMap;
import java.util.Map;

public class MobileBanking_POM {

    public static void SetPage_MB_CommomObjects() {

        Map<String, String> My_Page_Obejcts = new HashMap<String, String>();

        My_Page_Obejcts.put("tbnMainLogin", "ID|com.barclays.absa.banking.uat:id/loginButton");
        My_Page_Obejcts.put("txtBxAccountNumber", "XPATH|//android.view.ViewGroup/android.view.ViewGroup[1]//android.widget.EditText");
        My_Page_Obejcts.put("txtPIN", "XPATH|//android.view.ViewGroup/android.view.ViewGroup[2]//android.widget.EditText");
        My_Page_Obejcts.put("txtUserNumber", "XPATH|//android.view.ViewGroup/android.view.ViewGroup[3]//android.widget.EditText");
        My_Page_Obejcts.put("btnLogin", "ID|com.barclays.absa.banking.uat:id/loginButton");

        My_Page_Obejcts.put("lblSurephrase","ID|com.barclays.absa.banking.uat:id/tv_missing_char");
        My_Page_Obejcts.put("btnContinue","ID|com.barclays.absa.banking.uat:id/btn_linkDeviceContinue");

        My_Page_Obejcts.put("txtDeviceNickNmae", "XPATH|//android.view.ViewGroup/android.view.ViewGroup[2]//android.widget.EditText");
        My_Page_Obejcts.put("btnNext","ID|com.barclays.absa.banking.uat:id/saveAndContinueButton");

        My_Page_Obejcts.put("rdBtnFingerPrintNo","XPATH|//android.widget.RadioGroup/android.widget.RadioButton[2]");
        My_Page_Obejcts.put("btnFPContinue","ID|com.barclays.absa.banking.uat:id/fingerprintAuthProceedButton");
        My_Page_Obejcts.put("btnVerficationDeviceYes","ID|com.barclays.absa.banking.uat:id/sureCheckConfirmationPositive");
        My_Page_Obejcts.put("btnVerficationDeviceNo","ID|com.barclays.absa.banking.uat:id/sureCheckConfirmationNegative");


        My_Page_Obejcts.put("lblSuccessfull","ID|com.barclays.absa.banking.uat:id/successMessageText");
        My_Page_Obejcts.put("btmExploreLogIn","ID|com.barclays.absa.banking.uat:id/exploreButton");




        //Log In

        My_Page_Obejcts.put("btnGotIt","ID|com.barclays.absa.banking.uat:id/okGotItButton");

        //Home
        My_Page_Obejcts.put("txtPolicyName","XPATH|//android.view.ViewGroup/android.support.v7.widget.RecyclerView/android.view.ViewGroup[3]/android.widget.TextView[1]");
        My_Page_Obejcts.put("wgdtPolicyName","XPATH|//android.view.ViewGroup/android.support.v7.widget.RecyclerView/android.view.ViewGroup[3]");

        My_Page_Obejcts.put("frmNotify","ID|android:id/content");
        My_Page_Obejcts.put("lblPolicyDetails","ID|com.barclays.absa.banking.uat:id/view_pager");

        My_Page_Obejcts.put("lblClaimNotify","ID|com.barclays.absa.banking.uat:id/claim_notification_button");

        My_Page_Obejcts.put("txtDescription", "XPATH|//android.view.ViewGroup[4]//android.widget.EditText");

        My_Page_Obejcts.put("txtBxPhoneNumber", "XPATH|//android.widget.LinearLayout/android.view.ViewGroup[1]/android.widget.ImageView");
        My_Page_Obejcts.put("icnClainType", "XPATH|//android.widget.LinearLayout/android.view.ViewGroup[3]/android.widget.ImageView");
        My_Page_Obejcts.put("txtClaimType", "XPATH|//android.view.ViewGroup[3]//android.widget.EditText");

        My_Page_Obejcts.put("ClainType", "XPATH|//android.widget.TextView[@text='Death']");
        My_Page_Obejcts.put("btnNext_ClaimNotif", "ID|com.barclays.absa.banking.uat:id/next_button");

        My_Page_Obejcts.put("btnSubmit_ClaimNotif", "ID|com.barclays.absa.banking.uat:id/submit_button");

        My_Page_Obejcts.put("lblnoticeMessageTextView", "ID|com.barclays.absa.banking.uat:id/noticeMessageTextView");
        My_Page_Obejcts.put("imgresultImageView", "ID|com.barclays.absa.banking.uat:id/resultImageView");
        My_Page_Obejcts.put("btnDone", "ID|com.barclays.absa.banking.uat:id/topActionButton");




        WebDr.page_Objects=My_Page_Obejcts;
    }

}
