package WIMI_IOTF_POM;

import org.openqa.selenium.By;
import org.yaml.snakeyaml.error.MarkedYAMLException;
import utility.WebDr;

import java.util.HashMap;
import java.util.Map;

public class IOTF_PageObject {

	public static void SetPage_IOTF_CommomObjects()
	{
		Map<String, String> My_Page_Obejcts = new HashMap<String, String>();

		My_Page_Obejcts.put("tbnMainLogin","ID|com.barclays.absa.banking.uat:id/loginButton");
		My_Page_Obejcts.put("txtBxAccountNumber","XPATH|//android.view.ViewGroup/android.view.ViewGroup[1]//android.widget.EditText");
		My_Page_Obejcts.put("txtPIN","XPATH|//android.view.ViewGroup/android.view.ViewGroup[2]//android.widget.EditText");
		My_Page_Obejcts.put("btnLogin","ID|com.barclays.absa.banking.uat:id/loginButton");


//    App Startup page



		//My_Page_Obejcts.put("lblTutorial1Header","ID|com.absa.iotfapp:id/description");
		My_Page_Obejcts.put("lblTutorial1Header","XPATH|//android.widget.TextView[@resource-id='com.absa.iotfapp:id/description']");
		//My_Page_Obejcts.put("lblTutorial1Header","XPATH|/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.view.ViewGroup/android.widget.FrameLayout/android.view.ViewGroup/android.support.v4.view.ViewPager/android.view.ViewGroup/android.widget.TextView[1]");
//		My_Page_Obejcts.put("btnNext","ID|com.absa.iotfapp:id/btn_skip");
		My_Page_Obejcts.put("lblTutorial1Info","ID|com.absa.iotfapp:id/info");
		My_Page_Obejcts.put("btnNext","XPATH|//android.widget.Button[1]");
		My_Page_Obejcts.put("lblTutorial2Header", "XPATH|//android.widget.LinearLayout[1]/android.widget.FrameLayout[1]/android.widget.LinearLayout[1]/android.widget.FrameLayout[1]/android.widget.RelativeLayout[1]/android.support.v4.view.ViewPager[1]/android.widget.LinearLayout[1]/android.widget.TextView[1]");
		My_Page_Obejcts.put("lblTutorial2Info","XPATH|/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.view.ViewGroup/android.widget.FrameLayout/android.view.ViewGroup/android.support.v4.view.ViewPager/android.view.ViewGroup/android.widget.TextView[2]");
		My_Page_Obejcts.put("lblTutorial3Header", "XPATH|//android.widget.LinearLayout[1]/android.widget.FrameLayout[1]/android.widget.LinearLayout[1]/android.widget.FrameLayout[1]/android.widget.RelativeLayout[1]/android.support.v4.view.ViewPager[1]/android.widget.LinearLayout[1]/android.widget.TextView[1]");
		My_Page_Obejcts.put("lblTutorial3Info","XPATH|/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.view.ViewGroup/android.widget.FrameLayout/android.view.ViewGroup/android.support.v4.view.ViewPager/android.view.ViewGroup/android.widget.TextView[2]");
		My_Page_Obejcts.put("lblTutorial4Header", "XPATH|//android.widget.LinearLayout[1]/android.widget.FrameLayout[1]/android.widget.LinearLayout[1]/android.widget.FrameLayout[1]/android.widget.RelativeLayout[1]/android.support.v4.view.ViewPager[1]/android.widget.LinearLayout[1]/android.widget.TextView[1]");
		My_Page_Obejcts.put("lblTutorial4Info","XPATH|/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.view.ViewGroup/android.widget.FrameLayout/android.view.ViewGroup/android.support.v4.view.ViewPager/android.view.ViewGroup/android.widget.TextView[2]");
		My_Page_Obejcts.put("lblTutorial5Header", "XPATH|//android.widget.LinearLayout[1]/android.widget.FrameLayout[1]/android.widget.LinearLayout[1]/android.widget.FrameLayout[1]/android.widget.RelativeLayout[1]/android.support.v4.view.ViewPager[1]/android.widget.LinearLayout[1]/android.widget.TextView[1]");
		//My_Page_Obejcts.put("lblTutorial4Info","XPATH|/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.view.ViewGroup/android.widget.FrameLayout/android.view.ViewGroup/android.support.v4.view.ViewPager/android.view.ViewGroup/android.widget.TextView[2]");
// My_Page_Obejcts.put("btnGetStarted","ID|com.absa.iotfapp:id/btn_done");
		//My_Page_Obejcts.put("btnGetStarted","XPATH|//android.widget.Button[@text='Getting Started']");
		My_Page_Obejcts.put("btnGetStarted","XPATH|//android.widget.Button[@text='GETTING STARTED']");


		My_Page_Obejcts.put("chkBxImpInfoScreen","XPATH|//android.widget.CheckBox[1]");
		//My_Page_Obejcts.put("btnNextButton","ID|com.absa.iotfapp:id/btnNext");
		//My_Page_Obejcts.put("btnNextButton","XPATH|///hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.view.View/android.widget.Button");
		//My_Page_Obejcts.put("btnNextButton","XPATH|//android.widget.Button[@resource-id='com.absa.iotfapp:id/btnNext]");
		My_Page_Obejcts.put("btnNextButton","XPATH|/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.view.ViewGroup/android.widget.Button\n");

		//Registration Screen
		My_Page_Obejcts.put("lblSignUpTtl","XPATH|//android.widget.TextView[@resource-id='com.absa.iotfapp:id/signedupTitle']");
		My_Page_Obejcts.put("lblSignUpTxt","XPATH|//android.widget.TextView[@resource-id='com.absa.iotfapp:id/signup_text_title']");

		My_Page_Obejcts.put("lblIDErrorMsg","XPATH|//android.widget.TextView[@resource-id='com.absa.iotfapp:id/idError']");
		//My_Page_Obejcts.put("btnPassport","XPATH|//android.widget.Button[@text='Passport']");
		My_Page_Obejcts.put("btnPassport","XPATH|//android.widget.Button[@text='PASSPORT']");
		My_Page_Obejcts.put("btnSAID","XPATH|//android.widget.Button[@text='SA ID']");
		My_Page_Obejcts.put("txtBxEnterID","XPATH|//android.widget.EditText[@text='Enter your ID number']");
		//My_Page_Obejcts.put("txtBxEnterPassport","ID|com.absa.iotfapp:id/edit_id_pass_registration");
		//My_Page_Obejcts.put("txtBxEnterPassport","XPATH|//android.widget.EditText[@text='Enter your passport number']");
		My_Page_Obejcts.put("txtBxEnterPassport","XPATH|//android.widget.EditText[@class='android.widget.EditText']");

		My_Page_Obejcts.put("lnkAlreadyAccount","XPATH|//android.widget.TextView[@text='I already have an account']");
		My_Page_Obejcts.put("swtABSAProductON","XPATH|//android.widget.Switch[@text='I have an Absa product ON']");
		My_Page_Obejcts.put("swtABSAProductOFF","XPATH|//android.widget.Switch[@text='I have an Absa product OFF']");
		//My_Page_Obejcts.put("txtBxCellNumber","ID|com.absa.iotfapp:id/txtCell");
		My_Page_Obejcts.put("txtBxCellNumber","XPATH|//android.widget.EditText[@resource-id='com.absa.iotfapp:id/editCellphone']");
		My_Page_Obejcts.put("btnRegNext","XPATH|//android.widget.Button[@text='NEXT']");

		My_Page_Obejcts.put("btnAlreadyHvAccount","XPATH|//android.widget.TextView[@text='I already have an account']");

		//OTP

//		My_Page_Obejcts.put("txtBxOTP","ID|com.absa.iotfapp:id/editOpt");
		My_Page_Obejcts.put("txtBxOTP","XPATH|//android.widget.EditText[@resource-id='com.absa.iotfapp:id/editOpt']");
//		My_Page_Obejcts.put("btmOTPNext","ID|com.absa.iotfapp:id/bnSubmit");
		My_Page_Obejcts.put("btmConfirmOTP","XPATH|//android.widget.Button[@text='CONFIRM OTP']");
		//My_Page_Obejcts.put("btmConfirmOTP","XPATH|//android.widget.Button[@text='Confirm OTP']");

		My_Page_Obejcts.put("lnkResendOTP","XPATH|//android.widget.TextView[@resource-id='com.absa.iotfapp:id/resendOtp']");
		My_Page_Obejcts.put("lblOTPVerify","XPATH|//android.widget.TextView[@resource-id='com.absa.iotfapp:id/verify']");
		My_Page_Obejcts.put("lblOTPNo","XPATH|//android.widget.TextView[@resource-id='com.absa.iotfapp:id/otpNo']");
		My_Page_Obejcts.put("lblInsertOTP","XPATH|//android.widget.TextView[@resource-id='com.absa.iotfapp:id/insertOpt']");
		//My_Page_Obejcts.put("lnkResendOTP","XPATH|//android.widget.TextView[@resource-id='com.absa.iotfapp:id/resendOtp']");


		//Nickname
		My_Page_Obejcts.put("lblCreateNickname","XPATH|//android.widget.TextView[@resource-id='com.absa.iotfapp:id/createNickname']");
		My_Page_Obejcts.put("lblNNUnique","XPATH|//android.widget.TextView[@resource-id='com.absa.iotfapp:id/unique']");
		My_Page_Obejcts.put("txtBxNickname","XPATH|//android.widget.EditText[@resource-id='com.absa.iotfapp:id/editNickname']");
		My_Page_Obejcts.put("btnNickNameNext","XPATH|//android.widget.Button[@text='NEXT']");


		//Password
		//My_Page_Obejcts.put("txtPassword","ID|com.absa.iotfapp:id/editPassword");
		My_Page_Obejcts.put("txtPassword","XPATH|//android.widget.EditText[@text='Enter Password']");
		//My_Page_Obejcts.put("txtPassword","XPATH|//android.widget.EditText@resource-id='com.absa.iotfapp:id/editPassword']");
		My_Page_Obejcts.put("txtConfirmPassword","XPATH|//android.widget.EditText[@text='Re-enter password']");
		//My_Page_Obejcts.put("btnPassWordNext","XPATH|//android.widget.EditText[@text='NEXT']");
		My_Page_Obejcts.put("btnPassWordNext","XPATH|/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.view.ViewGroup/android.widget.Button");




		//Success Screen
		My_Page_Obejcts.put("lblCongrats","XPATH|//android.widget.TextView[@resource-id='com.absa.iotfapp:id/congrats_text_title']");
		My_Page_Obejcts.put("lblSuccessText","XPATH|//android.widget.TextView[@resource-id='com.absa.iotfapp:id/successful_text']");
		My_Page_Obejcts.put("btnResultGetStarted","XPATH|//android.widget.Button[@resource-id='com.absa.iotfapp:id/successButton']");
		My_Page_Obejcts.put("imgSuccessImage","XPATH|//android.widget.ImageView[@resource-id='com.absa.iotfapp:id/success_image']");

//android.widget.ImageView[@resource-id='com.absa.iotfapp:id/success_image']
		//android.widget.Button[@resource-id='com.absa.iotfapp:id/successButton']

		My_Page_Obejcts.put("btnAllow","XPATH|//android.widget.Button[@text='ALLOW']");


		//Dashboard
		My_Page_Obejcts.put("iconProfilePic","ID|com.absa.iotfapp:id/dashboard_user_nickname_textview");
		My_Page_Obejcts.put("lblHelloText","XPATH|/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.view.ViewGroup/android.widget.FrameLayout[1]/android.widget.ScrollView/android.view.ViewGroup/android.widget.TextView[1");
		My_Page_Obejcts.put("lblDate","ID|com.absa.iotfapp:id/dashboard_today_date_textview");
		My_Page_Obejcts.put("lblPercentage","ID|com.absa.iotfapp:id/dashboard_user_last_trip_precentage_textview");
		My_Page_Obejcts.put("lblWeeklyProgressText","ID|com.absa.iotfapp:id/weekly_progress");
		My_Page_Obejcts.put("lblUserDistanceText","ID|com.absa.iotfapp:id/dashboard_user_distance");
		My_Page_Obejcts.put("lblUserDurationText","ID|com.absa.iotfapp:id/dashboard_user_duration");
		My_Page_Obejcts.put("lblUserSpeedingText","ID|com.absa.iotfapp:id/dashboard_user_speeding");
		My_Page_Obejcts.put("imgUserGage","ID|com.absa.iotfapp:id/dashboard_user_trip_percentage_progressview");
		My_Page_Obejcts.put("tabMyMoments","ID|com.absa.iotfapp:id/dashboard_my_moments_layout");
		My_Page_Obejcts.put("lblStillLearningText","XPATH|/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.view.ViewGroup/android.widget.FrameLayout[1]/android.widget.ScrollView/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup/android.widget.TextView[1]");




		//re-login
		My_Page_Obejcts.put("btnSubmit","XPATH|//android.widget.Button[@text='SUBMIT']");

		//Menu Options
		My_Page_Obejcts.put("btnMenu","XPATH|//android.widget.FrameLayout[@content-desc=\"Menu\"]/android.widget.ImageView");
		My_Page_Obejcts.put("btnLogout","XPATH|//android.widget.TextView[@text='Logout']");
		My_Page_Obejcts.put("btnYesLogout","XPATH|//android.widget.Button[@text='YES']");


		My_Page_Obejcts.put("lblListOfServices","XPATH|//android.widget.TextView[@text='List of emergency services']");

		//Bottom Navigation Menu
		My_Page_Obejcts.put("btnHome","ID|com.absa.iotfapp:id/navigation_home");
		My_Page_Obejcts.put("BtnEmergency","XPATH|//android.widget.FrameLayout[@content-desc=\"Emergency\"]/android.widget.ImageView");

		WebDr.page_Objects=My_Page_Obejcts;






	}

}
