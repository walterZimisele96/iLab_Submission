package WIMI_IOTF;

import WIMI_IOTF_POM.IOTF_PageObject;
import com.relevantcodes.extentreports.ExtentTest;
import org.openqa.selenium.WebDriver;
import utility.WebDr;

public class Smart_Car extends WebDr {

    public Smart_Car(WebDriver wdriver, ExtentTest test) {
        this.wdriver = wdriver;
        this.test = test;
    }

    public boolean fn_Smart_Car() throws Exception {
        boolean blnSmart_Car = false;
        IOTF_PageObject.SetPage_IOTF_CommomObjects();

        try{

            String sID_Type = getValue ("ID_Type");
            String sID_Number = getValue ("ID_Number");

           // String sTutorial1Header = getText("lblTutorial1Header","Tutorial 1 Header");
            //validateString("Are you the best driver", sTutorial1Header.replace("\n", ""), "Tutorial 1 Header");

            //String sTutorial1Info  = getText("lblTutorial1Info","Tutorial 1 Info");
            //validateString("Smart Car assesses your driving" + "\n" + "behaviour and helps you drive " + "\n" + "better.Compete and find out where" + "\n" +
              //      "you rank in SA today!",sTutorial1Info,"Tutorial 1 Info");



            click("btnNext","Next Button");


            click("btnNext","Next Button");

            click("btnNext","Next Button");


            click("btnNext","Next Button");


            click("btnGetStarted","Get Started");

            click("chkBxImpInfoScreen","Important Information Checkbox");
            click("btnNextButton","Next Button in Important Information");


            click("btnAlreadyHvAccount","I Already have an account button");

            if (sID_Type.equals("Passport")) {
                click("btnPassport", "Select Passport");

                setText("txtBxEnterPassport", sID_Number, "Enter Passport Number");
            } else {
                setText("txtBxEnterID", sID_Number, "Enter Passport Number");
            }

            click("btnSubmit", "Submit button for re-login");
            setText("txtBxOTP","123456", "Enter OTP");
            click("btmConfirmOTP","Next Button on OTP Screen");

            click("btnAllow","Allow location");
            click("btnAllow","Allow location");

            click("btnMenu","Menu button");


            blnSmart_Car = true;





        }catch (Exception e) {
            WriteStep (wdriver,"Execution in Bottom navigation menu","Execution in Bottom navigation menu", e.toString (), "FAIL");
        }


        return blnSmart_Car;
    }
}
