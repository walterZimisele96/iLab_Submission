package WIMI_IOTF;

import WIMI_IOTF_POM.IOTF_PageObject;
import com.relevantcodes.extentreports.ExtentTest;
import junit.framework.Assert;
import org.openqa.selenium.WebDriver;
import utility.WebDr;

public class IOTF_NavMenu extends WebDr {

    public IOTF_NavMenu(WebDriver wdriver, ExtentTest test) {
        this.wdriver = wdriver;
        this.test = test;
    }

    public boolean fn_IOTF_NavMenu() throws Exception {
        boolean blnIOTF_Navigate = false;
        IOTF_PageObject.SetPage_IOTF_CommomObjects();

        try{

            String sID_Type = getValue ("ID_Type");
            String sID_Number = getValue ("ID_Number");

            //First tutorial screen

            wait(3000);

           // if(exists("lblTutorial1Header",true,"Tutorial 1 Header")){
             //   String sTutorial1Info  = getText("lblTutorial1Info","Tutorial 1 Info");
               // validateString("Smart Car assesses your driving" + "\n" + "behaviour and helps you drive " + "\n" + "better.Compete and find out where" + "\n" +
                 //       "you rank in SA today!",sTutorial1Info,"Tutorial 1 Info");
                click("btnNext","Next Button");

            //}

            //Second tutorial screen
            //if(exists("lblTutorial2Header",true,"Tutorial 2 Header")){
              //  String sTutorial2Info = getText("lblTutorial2Info","Tutorial 2 Info");
                //validateString("Discover more about your driving" + "\n" + "behaviour, travel patterns, lifestyle" +"\n" + "habits and more with My Moments." ,sTutorial2Info,"Tutorial 2 Info");
                click("btnNext","Next Button");

            //}

            //Third tutorial screen
            //if (exists("lblTutorial3Header",true,"Tutorial 3 Header")){
              //  String sTutorial3Info = getText("lblTutorial3Info","Tutorial 3 Info");
                //validateString("A handy SOS function to assist" + "\n" + "in the event of an accident," +"\n" + "emergency of breakdown.",sTutorial3Info,"Tutorial 3 Info");
                click("btnNext","Next Button");

            //}

            //Fourth tutorial screen
            //if(exists("lblTutorial4Header",true,"Tutorial 4 Header")){
              //  String sTutorial4Info = getText("lblTutorial4Info","Tutorial 4 Info");
                //validateString("We're always looking at new ways to" +"\n" + "improve your insurance experience-" + "\n" + "and we have so many of this in the" +
                  //      "\n" + "pipeline. Watch the space!",sTutorial4Info,"Tutorial 4 Info");
                click("btnNext","Next Button");

            //}

            //Fifth tutorial screen
           // if(exists("lblTutorial5Header",true,"Tutorial 5 Header")){

             //   String sTutorial5Info = getText("lblTutorial5Info","Tutorial 5 Info");
               // validateString("We will be using your locational" +"\n" + "movements to learn more about your" + "\n" + "travel behaviours. This could take up to"
                 //       + "\n" +"7 days to display on the app.",sTutorial5Info,"Tutorial 5 screen");
                click("btnGetStarted","Get Started");

            //}

            click("chkBxImpInfoScreen","Important Information Checkbox");
            click("btnNextButton","Next Button in Important Information");


            click("btnAlreadyHvAccount","I Already have an account button");

            if (sID_Type.equals("Passport")) {
                click("btnPassport", "Select Passport");

                setText("txtBxEnterPassport", sID_Number, "Enter Passport Number");
            } else {
                setText("txtBxEnterID", sID_Number, "Enter Passport Number");
            }

            click("btnSubmit", "Submit button for re-login");
            setText("txtBxOTP","123456", "Enter OTP");
            click("btmConfirmOTP","Next Button on OTP Screen");

            click("btnAllow","Allow location");
            click("btnAllow","Allow location");
            //click("btnMenu","Menu button");
            click("","");
            blnIOTF_Navigate = true;





        }catch (Exception e) {
            WriteStep (wdriver,"Execution in Bottom navigation menu","Execution in Bottom navigation menu", e.toString (), "FAIL");
        }


        return blnIOTF_Navigate;
    }


}
