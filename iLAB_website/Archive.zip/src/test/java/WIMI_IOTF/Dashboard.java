package WIMI_IOTF;

import WIMI_IOTF_POM.IOTF_PageObject;
import com.relevantcodes.extentreports.ExtentTest;
import junit.framework.Assert;
import org.openqa.selenium.WebDriver;
import utility.WebDr;

public class Dashboard  extends WebDr {


    public Dashboard(WebDriver wdriver, ExtentTest test) {
        this.wdriver = wdriver;
        this.test = test;
    }

    public boolean fn_Dashboard() throws Exception {
        boolean blnIOTF_Dashboard = false;
        IOTF_PageObject.SetPage_IOTF_CommomObjects();

        try{

            String sID_Type = getValue ("ID_Type");
            String sID_Number = getValue ("ID_Number");

            //First tutorial screen


           // String sTutorial1Header = getText("lblTutorial1Header","Tutorial 1 Header");
            //validateString("Are you the best driver", sTutorial1Header.replace("\n", ""), "Tutorial 1 Header");

            //String sTutorial1Info  = getText("lblTutorial1Info","Tutorial 1 Info");
            //validateString("Smart Car assesses your driving" + "\n" + "behaviour and helps you drive " + "\n" + "better.Compete and find out where" + "\n" +
             //       "you rank in SA today!",sTutorial1Info,"Tutorial 1 Info");

        //    Assert.assertEquals("Are you the best driver",sTutorial1Header);
            click("btnNext","Next Button");

            //Second tutorial screen
            //String sTutorial2Header = getText("lblTutorial1Header","Tutorial 2 Header");
            //validateString("Do more.See more.Get more.", sTutorial2Header.replace("\n", ""), "Tutorial 2 Header");

            //String sTutorial2Info = getText("lblTutorial2Info","Tutorial 2 Info");
            //validateString("Discover more about your driving" + "\n" + "behaviour, travel patterns, lifestyle" +"\n" + "habits and more with My Moments." ,sTutorial2Info,"Tutorial 2 Info");
            click("btnNext","Next Button");

            //Third tutorial screen
            //String sTutorial3Header = getText("lblTutorial1Header","Tutorial 3 Header");
            //validateString("Help that’s always on hand.", sTutorial3Header.replace("\n", ""), "Tutorial 3 Header");

            //String sTutorial3Info = getText("lblTutorial3Info","Tutorial 3 Info");
            //validateString("A handy SOS function to assist" + "\n" + "in the event of an accident," +"\n" + "emergency of breakdown.",sTutorial3Info,"Tutorial 3 Info");
            click("btnNext","Next Button");

            //Fourth tutorial screen
            //String sTutorial4Header = getText("lblTutorial1Header","Tutorial 4 Header");
            //validateString("Insurance at your fingertips.", sTutorial4Header.replace("\n", ""), "Tutorial 4 Header");

            //String sTutorial4Info = getText("lblTutorial4Info","Tutorial 4 Info");
            //validateString("We're always looking at new ways to" +"\n" + "improve your insurance experience-" + "\n" + "and we have so many of this in the" +
                   // "\n" + "pipeline. Watch the space!",sTutorial4Info,"Tutorial 4 Info");
            click("btnNext","Next Button");

            //Fifth tutorial screen
            //String sTutorial5Header = getText("lblTutorial1Header","Tutorial 5 Header");
            //validateString("We’re learning more about you.", sTutorial5Header.replace("\n", ""), "Tutorial 5 Header");

            //String sTutorial5Info = getText("lblTutorial5Info","Tutorial 5 Info");
            //validateString("We will be using your locational" +"\n" + "movements to learn more about your" + "\n" + "travel behaviours. This could take up to"
              //      + "\n" +"7 days to display on the app.",sTutorial5Info,"Tutorial 5 screen");
            click("btnGetStarted","Get Started");

            click("chkBxImpInfoScreen","Important Information Checkbox");
            click("btnNextButton","Next Button in Important Information");


            click("btnAlreadyHvAccount","I Already have an account button");

            if (sID_Type.equals("Passport")) {
                click("btnPassport", "Select Passport");

                setText("txtBxEnterPassport", sID_Number, "Enter Passport Number");
            } else {
                setText("txtBxEnterID", sID_Number, "Enter Passport Number");
            }

            click("btnSubmit", "Submit button for re-login");
            setText("txtBxOTP","123456", "Enter OTP");
            click("btmConfirmOTP","Next Button on OTP Screen");


           // click("btnMenu","Menu button");

            click("btnAllow","Allow location");
            click("btnAllow","Allow location");

            //if(exists("lblHelloText",true,"Welcome Message")){

              //  exists("iconProfilePic",true,"User Profile Picture");
                //exists("imgUserGage",true,"Gage Image");

                //String sStillLearning = getROPropertyValue("lblStillLearningText","text","Still learning you text");
                //validateString("Still learning",sStillLearning,"Still learning you text");




           // }

            //validateString();


            blnIOTF_Dashboard = true;





        }catch (Exception e) {
            WriteStep (wdriver,"Execution in Dashboard","Execution in Dashboard", e.toString (), "FAIL");
        }


        return blnIOTF_Dashboard;
    }


}
