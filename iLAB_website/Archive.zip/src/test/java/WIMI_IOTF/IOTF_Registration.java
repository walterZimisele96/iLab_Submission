package WIMI_IOTF;

import WIMI_IOTF_POM.IOTF_PageObject;
import com.relevantcodes.extentreports.ExtentTest;
import io.appium.java_client.MobileDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;
import junit.framework.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.interactions.touch.TouchActions;
import org.openqa.selenium.support.ui.Select;
import utility.WebDr;

import java.awt.*;
import java.awt.event.KeyEvent;
import java.util.Calendar;
import java.util.List;

public class IOTF_Registration extends WebDr{

	public IOTF_Registration(WebDriver wdriver, ExtentTest test) {
		this.wdriver = wdriver;
		this.test = test;
	}

	private By lblT1 = By.xpath("//android.widget.TextView[@resource-id='com.absa.iotfapp:id/description']");

	
	public boolean fn_IOTF_Registration() throws Exception {
		boolean blnIOTF_Reg = false;
		IOTF_PageObject.SetPage_IOTF_CommomObjects();

        try
		{

			String sABSA_Account_Holder = getValue ("ABSA_Account_Holder");
			String sID_Type = getValue ("ID_Type");
			String sID_Number = getValue ("ID_Number");
			String sCell_Number = getValue ("Cell_Number");
			String sPassword = getValue ("Password");
			String sNickname = getValue ("Nickname");

			//strGetText(lblT1);

			//WebElement lbl1 = driver.findElement(By.id("com.absa.iotfapp:id/info"));

			//String actual = lbl1.getText();

			//Assert.assertEquals("Smart Car assesses your driving behaviour and helps you drive better.Compete and find out where you rank in SA today!",actual);



			//Assert.assertEquals("Are you the best driver",lblT1);



			//First tutorial screen

			//if(exists("lblTutorial1Header",true,"Tutorial 1 Header")){
				//String sTutorial1Info  = getText("lblTutorial1Info","Tutorial 1 Info");
				//validateString("Smart Car assesses your driving" + "\n" + "behaviour and helps you drive " + "\n" + "better.Compete and find out where" + "\n" +
				//"you rank in SA today!",sTutorial1Info,"Tutorial 1 Info");
			//String sTutorial1Header = getText("lblTutorial1Header","Tutorial 1 Header");
			//String sTutorial1Header = strGetText();

			//Assert.assertEquals("Are you the best driver",sTutorial1Header);
				click("btnNext","Next Button");

			//}

			//Second tutorial screen
			//if(exists("lblTutorial2Header",true,"Tutorial 2 Header")){
			//	String sTutorial2Info = getText("lblTutorial2Info","Tutorial 2 Info");
			//	validateString("Discover more about your driving" + "\n" + "behaviour, travel patterns, lifestyle" +"\n" + "habits and more with My Moments." ,sTutorial2Info,"Tutorial 2 Info");
				click("btnNext","Next Button");

			//}

			//Third tutorial screen
		//	if (exists("lblTutorial3Header",true,"Tutorial 3 Header")){
		//		String sTutorial3Info = getText("lblTutorial3Info","Tutorial 3 Info");
		//		validateString("A handy SOS function to assist" + "\n" + "in the event of an accident," +"\n" + "emergency of breakdown.",sTutorial3Info,"Tutorial 3 Info");
				click("btnNext","Next Button");

		//	}

			//Fourth tutorial screen
		//	if(exists("lblTutorial4Header",true,"Tutorial 4 Header")){
		//		String sTutorial4Info = getText("lblTutorial4Info","Tutorial 4 Info");
		//		validateString("We're always looking at new ways to" +"\n" + "improve your insurance experience-" + "\n" + "and we have so many of this in the" +
		//				"\n" + "pipeline. Watch the space!",sTutorial4Info,"Tutorial 4 Info");
				click("btnNext","Next Button");

		//	}

			//Fifth tutorial screen
		//	if(exists("lblTutorial5Header",true,"Tutorial 5 Header")){

		//		String sTutorial5Info = getText("lblTutorial5Info","Tutorial 5 Info");
		//		validateString("We will be using your locational" +"\n" + "movements to learn more about your" + "\n" + "travel behaviours. This could take up to"
		//				+ "\n" +"7 days to display on the app.",sTutorial5Info,"Tutorial 5 screen");
				click("btnGetStarted","Get Started");

		//	}



			click("chkBxImpInfoScreen","Important Information Checkbox");
			click("btnNextButton","Next Button in Important Information");

//			Registration Screen
			//if (exists("lblSignUpTtl",true,"SignUp screen")) {

			//	String sSignUpTtl = getROPropertyValue("lblSignUpTtl","text","Sign Up Title ");
			//	validateString("Let's get you signed up",sSignUpTtl,"Sign up screen Header");
//
			//	String sSignUpTxt = getROPropertyValue("lblSignUpTxt","text","Sign Up text");
			//	validateString("Please enter your SA ID or passport number",sSignUpTxt,"Sign up screen Header");

				click("btnNextButton", "Next Button in Registration screen");
			//	exists("lblIDErrorMsg",true,"Error message when user does not enter ID number");


			//	exists("swtABSAProductON", true, "I have an Absa product should be ON");
			  //  exists("lnkAlreadyAccount",true,"I already have an account");

				//if (sABSA_Account_Holder.equals("No")){
					click("swtABSAProductON", "Switch off for Non Policy Holder");
                    //sID_Number = "";
				//}

				if (sID_Type.equals("Passport")) {
					click("btnPassport", "Select Passport");

					setText("txtBxEnterPassport", sID_Number, "Enter Passport Number");
				} else {
					setText("txtBxEnterID", sID_Number, "Enter Passport Number");
				}


				if (sABSA_Account_Holder.equals("No")) {
					setText("txtBxCellNumber", sCell_Number, "Enter Cell Number");
				}
				click("btnRegNext", "Next Button in Registration screen");
				//click("btnRegNext", "Next Button in Registration screen");

			//}else{
			  //  return blnIOTF_Reg;
          //}


			//if (exists("txtBxOTP",true, "OTP Screen")){
			//	String sOTPVerify = getText("lblOTPVerify","OTP Verify Text");
			//	validateString("Verify your number", sOTPVerify.replace("\n", ""), "OTP Verify Text");

			//	String sOTPNo = getText("lblOTPNo","OTP Number Text");
			//	validateString("You will receive your OTP via SMS  on your number ******2744. Is this correct? If not please call 0861 890 987 or we can call you back", sOTPNo, "OTP Verify Text");

			//	String sInsertOTP = getText("lblInsertOTP","OTP Verify Text");
			//	validateString("This request will timeout in 60 seconds if you have not inserted  your OTP.", sInsertOTP.replace("\n", ""), "OTP Verify Text");

			//	exists("lnkResendOTP",true,"Resend OTP");

			setText("txtBxOTP","123456", "Enter OTP");
				click("btmConfirmOTP","Next Button on OTP Screen");
			click("btmConfirmOTP","Next Button on OTP Screen");
				//}else{
	              // return blnIOTF_Reg;
           //}

			//if (exists("lblCreateNickname",true,"Create Nickname Label")){
			  //  String sCreateNN = getROPropertyValue("lblCreateNickname","text","Create Nickname");
		    //validateString("Create a nickname",sCreateNN,"Create Nickname Header");

              // String slblNNUnique = getROPropertyValue("lblNNUnique","text","Create Nickname Unique Text");
                //validateString("Create a unique nickname to secure your account.",slblNNUnique.replace("\n", ""),"Create Nickname Unique Text" );


                setText("txtBxNickname",sNickname,"Nickname");
                click("btnNickNameNext","Next Button on Nickname Screen");
	            //}else{
	               //return blnIOTF_Reg;
           //}

            if (sABSA_Account_Holder.equals("Yes")) {
			    //Password Screen

				setText("txtPassword", sPassword, "Enter Password");
				setText("txtConfirmPassword", sPassword, "Confirm Password");
				click("btnPassWordNext","Next Button on Password Screen");

            }

			setText("txtBxNickname",sNickname,"Nickname");
			click("btnNickNameNext","Next Button on Nickname Screen");


           //if (exists("lblCongrats",true,"Result Screen")){
             //   String sSuccesText = getROPropertyValue("lblSuccessText","text","Result Screen - Success Text");
               // validateString("You have been successfully registered",sSuccesText,"Result Screen - Success Text");

                //exists("imgSuccessImage", true, "Success Image");

                click("btnResultGetStarted", "Get Started Button in Success Screen");

            	//click("btnAllow","Allow Location");

                blnIOTF_Reg = true;
	          //}else{
               //return blnIOTF_Reg;
            //}
				click("btnAllow","Allow location");
			click("btnAllow","Allow location");

				click("btnMenu","Menu button");

				click("btnLogout","Logout button");

				click("btnYesLogout","Allow logout");

			if (sID_Type.equals("Passport")) {
				click("btnPassport", "Select Passport");

				setText("txtBxEnterPassport", sID_Number, "Enter Passport Number");
			} else {
				setText("txtBxEnterID", sID_Number, "Enter Passport Number");
			}

			click("btnSubmit", "Submit button for re-login");





		} catch (Exception e) {
			WriteStep (wdriver,"Execution in IOTF Registration Flow","Execution of IOTF Registration Flow", e.toString (), "FAIL");
		}
		return blnIOTF_Reg;
	}
}
