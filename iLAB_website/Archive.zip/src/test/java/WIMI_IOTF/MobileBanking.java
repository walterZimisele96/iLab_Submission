package WIMI_IOTF;

import WIMI_IOTF_POM.IOTF_PageObject;
import WIMI_IOTF_POM.MobileBanking_POM;
//import android.view.View;
import com.relevantcodes.extentreports.ExtentTest;

import io.appium.java_client.android.Activity;
import io.appium.java_client.android.AndroidDriver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import sun.awt.im.InputMethodManager;
import utility.WebDr;

//import android.app.Activity;
//import android.content.Context;
//import android.graphics.Rect;
//import android.view.View;
//import android.view.inputmethod.InputMethodManager;
//
//import javax.swing.text.View;

import java.util.List;

import static netscape.javascript.JSObject.getWindow;

public class MobileBanking extends WebDr {

//    public MobileBanking(WebDriver wdriver, ExtentTest test) {
//        this.wdriver = wdriver;
//        this.test = test;
//    }
//
//    public void  ABSA_MB_Registration() throws Exception {
//        MobileBanking_POM.SetPage_MB_CommomObjects();
//        try {
//
//            String sAccountNumber = getValue("Account Number");
//            Thread.sleep(5000);
//            click("tbnMainLogin", "Log In");
//            setText("txtBxAccountNumber", sAccountNumber, "Account Number");
//            setText("txtPIN", sAccountNumber.substring(5), "Account PIN");
//            click("btnLogin", "Login");
//
//            if (exists("lblSurephrase",true,"SurePhrase")){
//                String sSurePhrase = getText("lblSurephrase","SurePhrase text");
//                String sFirst = sSurePhrase.split(",")[0];
//                sFirst = sFirst.split("the ")[1].trim();
//
//                String sSecond = sSurePhrase.split(",")[1];
//                sSecond = sSecond.split(" and")[0].trim();
//
//                String sThird = sSurePhrase.split(",")[1];
//                sThird = sThird.split("and ")[1];
//                sThird = sThird.split(" ")[0];
//
//                String[] arrMissingNum = (sFirst + ";" + sSecond + ";" + sThird).split(";");
//                for(int i = 0;i<=2;i++){
//                    String sPasswordNum = "";
//                    String sPassword = "Password1";
//                    String sNum = arrMissingNum[i];
//                    switch (sNum){
//                        case "first" : sPasswordNum = "1"; sPassword = "p";break;
//                        case "second" : sPasswordNum = "2";sPassword = "a";break;
//                        case "third" : sPasswordNum = "3";sPassword = "s";break;
//                        case "fourth" : sPasswordNum = "4";sPassword = "s";break;
//                        case "fifth" : sPasswordNum = "5";sPassword = "w";break;
//                        case "sixth" : sPasswordNum = "6";sPassword = "o";break;
//                        case "seventh" : sPasswordNum = "7";sPassword = "r";break;
//                        case "eighth" : sPasswordNum = "8";sPassword = "d";break;
//                        case "ninth" : sPasswordNum = "9";sPassword = "1";break;
//                    }
//                    wdriver.findElement(By.id("com.barclays.absa.banking.uat:id/et_password"+sPasswordNum)).sendKeys(sPassword);
//                }
//
//                click("btnContinue","Continue button in Surephase");
//
//            }else{
//                return ;
//            }
//
//
//
//            setText("txtDeviceNickNmae","TestDevice","Device nickname");
//            click("btnNext","Next Button in Nickname screen");
//
//            String[] arrPasscodeKey = ("2;3;5;7;8").split(";");
//            for(int keyNum=0;keyNum<=4;keyNum++){
//                String passcodeKeyID = "com.barclays.absa.banking.uat:id/button"+arrPasscodeKey[keyNum]+"_text_view";
//
//                wdriver.findElement(By.id(passcodeKeyID)).click();
//            }
//            WriteStep(wdriver,"Select Passcode ", "Select Passcode ", "Passcode Selected - 23578", "PASS");
//            Thread.sleep(2000);
//
//            for(int keyNum=0;keyNum<=4;keyNum++){
//                String passcodeKeyID = "com.barclays.absa.banking.uat:id/button"+arrPasscodeKey[keyNum]+"_text_view";
//
//                wdriver.findElement(By.id(passcodeKeyID)).click();
//            }
//            WriteStep(wdriver,"Confirm Passcode ", "Confirm Passcode - 23578", "Passcode Selected - 23578", "PASS");
//
//            click("rdBtnFingerPrintNo","Finger Print - No");
//            click("btnFPContinue","Continue Button - Finger Print");
//
//            click("btnVerficationDeviceNo", "Verification Device - No");
//
//            click("btmExploreLogIn","Explore - LogIn Button");
//        }
//        catch(Exception e){
//            throw e;
//        }
//    }
//
//    public void ABSA_MB_Login() throws Exception{
//        MobileBanking_POM.SetPage_MB_CommomObjects();
//        try {
//
//            String[] arrPasscodeKey = ("2;3;5;7;8").split(";");
//            for(int keyNum=0;keyNum<=4;keyNum++){
//                String passcodeKeyID = "com.barclays.absa.banking.uat:id/button"+arrPasscodeKey[keyNum]+"_text_view";
//
//                wdriver.findElement(By.id(passcodeKeyID)).click();
//                WriteStep(wdriver,"Select Passcode ", "Select Passcode ", "Passcode Selected - " + arrPasscodeKey[keyNum], "PASS");
//            }
//
//            Thread.sleep(2000);
//
////            click("btnGotIt","Ok, Got It - Button");
//
//
//        }catch(Exception e){
//            throw e;
//        }
//    }
//
//    public void fn_Select_Policy(String sPolicyname) throws Exception{
//        MobileBanking_POM.SetPage_MB_CommomObjects();
//        String sUIPolicyname ="";
//        try {
////            wdriver.scrollToExact("Help").click();
//            //android.view.ViewGroup/android.support.v7.widget.RecyclerView/android.view.ViewGroup[3]/android.widget.TextView[1]
//            List<WebElement> lstPolicy = wdriver.findElements(By.xpath("//android.view.ViewGroup/android.support.v7.widget.RecyclerView/android.view.ViewGroup"));
//            for(int i = 1; i<=lstPolicy.size();i++){
//                sUIPolicyname = wdriver.findElement(By.xpath("//android.view.ViewGroup/android.support.v7.widget.RecyclerView/android.view.ViewGroup["+i+"]/android.widget.TextView[1]")).getText();
//                if (sUIPolicyname.equalsIgnoreCase(sPolicyname)) {
//                    validateString(sPolicyname,sUIPolicyname,"POLICY NAME");
//                    lstPolicy.get(i-1).click();
//                    WriteStep(wdriver,"Select Policy " ,"Select Policy " + sPolicyname, "Policy Selected - " + sUIPolicyname, "DONE");
//                    break;
//                }
//            }
//
//        }catch(Exception e){
//            throw e;
//        }
//
//    }
//
//
//    public void fn_VerifyPolicy() throws Exception{
//        try{
//            Thread.sleep(3000);
//            String sPolicyDetails = getText("lblPolicyDetails","Policy Details Text");
//            validateString("NOT BLANK",sPolicyDetails,"POLICY DESCRIPTION");
////            WriteStep(wdriver,"Policy Descripton","NOT BLANK",sPolicyDetails,"PASS");
//
//            click("lblClaimNotify","Notify us about the claim");
//
//        }catch(Exception e){
//
//        }
//    }
//
//
//    public void fn_RegisterClaim() throws Exception{
//        try{
//
//            Actions action = new Actions(wdriver);
////            action.moveTo( 10, 10);
//            action.moveToElement(wdriver.findElement(By.xpath("//android.widget.LinearLayout/android.view.ViewGroup[3]/android.widget.ImageView")));
//            action.perform();
//
//
//
//            setText("txtBxPhoneNumber","0747832744","Claim Phone Number");
//            click("icnClainType","Clain Type");
//            click("ClainType","Select Claim Type : Death");
////            setText("txtClaimType","Death","Claim Type");
//
//            setText("txtDescription","Test Automation","Claim Description");
//            click("btnNext_ClaimNotif","Next Button");
////            click("btnNext_ClaimNotif","Next Button");
//            click("btnSubmit_ClaimNotif","Submit Button");
//            click("btnDone","Done Button");
//
//
//
//
//        }catch(Exception e){
//
//        }
//    }
}
